﻿using System;
using System.Net;
using System.Net.Sockets;

namespace CSock
{
    public class Sockets
    {
        public static Socket CreateSocket()
        {
            return new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        public static void ShutdownSocket(Socket socket)
        {
            if (socket == null) 
                return;

            if (socket != null)
            {
                try
                {
                    socket.Shutdown(SocketShutdown.Both);
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine("[CSock] - Failed To Shutdown Socket: " + ex.Message);
                }
            }
        }

        public static void CloseSocket(Socket socket)
        {
            if (socket != null)
            {
                try
                {
                    socket.Close();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine("[CSock] - Failed To Close Socket: " + ex);
                }
            }
        }

        public static byte[] ReceiveDataFromSocket(Socket socket, int bufferSize = 1024)
        {
            byte[] buffer = new byte[bufferSize];
            if (socket != null)
            {
                try
                {
                    int bytesRead = socket.Receive(buffer);
                    Array.Resize(ref buffer, bytesRead);
                    return buffer;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[CSock] - Failed to Receive Data: " + ex.Message);
                    return null;
                }
            }
            return null;
        }

        public static Socket BindSocketToEndpoint(Socket socket, IPEndPoint localEndPoint)
        {
            if (socket != null)
            {
                try
                {
                    socket.Bind(localEndPoint);
                    return socket;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[CSock] - Failed To Bind Socket: " + ex.Message);
                    return null;
                }
            }
            return null;
        }

        public static bool IsSocketConnected(Socket socket)
        {
            if (socket == null) return false;
            try
            {
                return !(socket.Poll(1, SelectMode.SelectRead) && socket.Available == 0);
            }
            catch (SocketException)
            {
                return false;
            }
        }

        public static void SetSocketTimeout(Socket socket, int receiveTimeout, int sendTimeout)
        {
            if (socket != null)
            {
                socket.ReceiveTimeout = receiveTimeout;
                socket.SendTimeout = sendTimeout;
            }
        }

        public static void SendDataToSocket(Socket socket, byte[] buffer, int size)
        {
            if (socket != null)
            {
                try
                {
                    socket.Send(buffer, size, SocketFlags.Partial);
                }
                catch
                {
                    Console.WriteLine("[CSock] - Failed To Send Bytes To Socket: " + buffer.Length + size);
                }
            }
        }

        public static void SendDataToEndpoint(Socket socket, IPEndPoint endpoint)
        {
            if (socket != null)
            {
                try
                {
                    socket.SendTo(new byte[1024], endpoint);
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine("[CSock] - Failed To Send Data: " + ex);
                }
            }
        }

        public static void CleanSocket(Socket socket)
        {
            socket.Dispose();
        }
    }
}
