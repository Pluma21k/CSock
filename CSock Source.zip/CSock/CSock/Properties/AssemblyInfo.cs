﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CSock")]
[assembly: AssemblyDescription("Manage Sockets With Ease!")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CSock")]
[assembly: AssemblyCopyright("Copyright Plum©  2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("c7343202-974c-41f3-9f2e-d3d4e5e70e7c")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ObfuscateAssembly(true)]
